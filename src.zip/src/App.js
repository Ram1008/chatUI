import DesktopView from "./components/DesktopView";


function App() {
  return (
    <div >
      <DesktopView/>
    </div>
  );
}

export default App;
